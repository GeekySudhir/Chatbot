from typing import Dict, NewType, Union, Optional, List, get_type_hints

sha256 = NewType('sha_256_hash', str)